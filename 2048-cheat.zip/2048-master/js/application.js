window.requestAnimationFrame(function () {
  var gameManager = new GameManager(4, KeyboardInputManager, HTMLActuator, LocalStorageManager);

  const cheatToggle = document.getElementById('cheat-toggle');
  const cheatMenu = document.getElementById('cheat-menu');
  const cheatButtons = document.querySelectorAll('.cheat-btn');
  let selectedCheatValue = null;

  // 1. Hile menüsünü aç/kapat
  cheatToggle.addEventListener('click', function () {
    cheatMenu.classList.toggle('active');
  });

  // 2. Sayı seçme
  cheatButtons.forEach(btn => {
    btn.addEventListener('click', function () {
      cheatButtons.forEach(b => b.classList.remove('selected'));
      this.classList.add('selected');
      selectedCheatValue = parseInt(this.getAttribute('data-val'), 10);
    });
  });

  // 3. Oyun tahtasına tıklayarak sayıyı çakma
  document.addEventListener('click', function (event) {
    if (selectedCheatValue === null) return;
    const gridContainer = document.querySelector('.grid-container');
    if (!gridContainer || !gridContainer.contains(event.target)) return;

    const rows = document.querySelectorAll('.grid-row');
    let targetRow = -1, targetCol = -1;

    rows.forEach((row, rIdx) => {
      const cells = row.querySelectorAll('.grid-cell');
      cells.forEach((cell, cIdx) => {
        const rect = cell.getBoundingClientRect();
        if (event.clientX >= rect.left && event.clientX <= rect.right &&
            event.clientY >= rect.top && event.clientY <= rect.bottom) {
          targetRow = rIdx;
          targetCol = cIdx;
        }
      });
    });

    if (targetRow !== -1 && targetCol !== -1) {
      const grid = gameManager.grid;
      
      // Hücreye seçilen sayıyı doğrudan çak
      const tile = new Tile({ x: targetCol, y: targetRow }, selectedCheatValue);
      grid.cells[targetRow][targetCol] = tile;

      // Eski hayalet görüntüleri temizle ve tahtayı güncelle
      const tileContainer = document.querySelector('.tile-container');
      if (tileContainer) {
        tileContainer.innerHTML = '';
      }

      gameManager.actuate();
    }
  });
});